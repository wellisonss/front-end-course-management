export interface IMatricula {
  ID: string;
  ID_DISCIPLINA: string;
  ID_USUARIO: string;
}