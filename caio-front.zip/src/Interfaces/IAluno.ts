export interface IAluno {
    ID: string;
    NOME: string;
    SENHA?: number;
    MATRICULA?: number;
    CURSO: string;
    EMAIL: string;
  }