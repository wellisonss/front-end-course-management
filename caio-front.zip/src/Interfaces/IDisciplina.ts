export interface IDisciplina {
  ID: string;
  NOME: string;
  CURSO: string;
  DESCRICAO: string;
  COD_DISCIPLINA: string;
}