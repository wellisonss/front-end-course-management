export interface IProfessor {
  ID: string;
  NOME: string;
  EMAIL: string;
  SIAEP?: number;
  NUMERO?: number;
  DEPARTAMENTO: string;
  SENHA: string;
}