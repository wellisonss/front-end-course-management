<script setup lang="ts">
import TableAlunoVue from "@components/TableAluno.vue";
import PostModal from "@components/PostModal.vue";

</script>

<template> 
    <TableAlunoVue />
    <PostModal />
</template>

<style scoped>
</style>
