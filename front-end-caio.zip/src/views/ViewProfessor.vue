<script setup lang="ts">
import TableProfessorVue from "@components/TableProfessor.vue";
</script>

<template> 
    <TableProfessorVue />
</template>

<style scoped>
</style>
