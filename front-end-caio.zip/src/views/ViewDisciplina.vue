<script setup lang="ts">
import TableDisciplinaVue from "@components/TableDisciplina.vue";
</script>

<template> 
    <TableDisciplinaVue />
</template>

<style scoped>
</style>
