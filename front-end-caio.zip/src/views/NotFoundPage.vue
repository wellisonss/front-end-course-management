<template>
    <div>
Page not found
    </div>
</template>

<script setup lang="ts">

</script>

<style scoped>

</style>